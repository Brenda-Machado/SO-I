#include "debug.h"

__BEGIN_API

Debug::Begl Debug::begl;
Debug::Err Debug::error;

__END_API